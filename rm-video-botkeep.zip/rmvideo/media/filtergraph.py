"""Dựng chuỗi bộ lọc ffmpeg (hàm thuần chuỗi, không chạy gì): màu / khung hình, che dải chữ gốc, cổng tiếng nền lúc người gốc nói, cửa sổ giữ tiếng gốc, đoạn mở đầu, chuẩn độ to.

Tách từ core_video.py (Phase 6); core_video.py còn là mặt tiền tương thích."""
import math
import re
from contextvars import ContextVar

import config
from rmvideo.media import edl, ff, framing

# loudnorm một lượt (động) đoán độ to khi chưa nghe hết bài: đầu video nhỏ rồi to dần, tự nén lên xuống theo cửa
# sổ 3 giây (nghe "thở"), và độ to cuối cùng lệch mục tiêu. Hai lượt: đo độ to tích hợp EBU R128 của chính bản
# trộn (chỉ phần tiếng, không giải mã hình) rồi nhân MỘT hệ số cố định; bộ chặn đỉnh giữ đỉnh dưới -1.4 dBFS.
LOUDNORM = "loudnorm=I=-14:TP=-1.0:LRA=9"


# Chốt đầu ra tiếng 48 kHz STEREO ngay ở aresample. FFmpeg 8 (bản static-ffmpeg 3.0 tải trên Botkeep): aresample
# không ghi ochl thì cho mọi số kênh ở đầu ra và lỗi "Cannot select channel layout for the link between filters
# ... aresample ... and ... apad" khi nối sang apad (FFmpeg 6.1 thì chạy).
AOUT = "aresample=48000:ochl=stereo"


TARGET_LUFS = -14.0


PEAK_LIMIT = 0.8                  # -1.9 dBFS: sau khi nén AAC (đẩy đỉnh lên 0,5-1 dB, bản 48: +0,1 dBTP) vẫn dưới -1 dBTP


_LUFS_RE = re.compile(r"Integrated loudness:\s*I:\s*(-?[\d.]+|-inf) LUFS")


def _linear_gain_filter(gain_db: float) -> str:
    return f"volume={gain_db:.2f}dB,alimiter=limit={PEAK_LIMIT}:attack=5:release=60:level=false"


def band_to_output(top: float, bottom: float) -> tuple[int, int]:
    """Dải (tỉ lệ 0..1 trên video gốc) -> (y, h) pixel trên khung 720x1280 sau crop 4%.
    Nới mỗi bên 1.2% và cao tối thiểu 96px để che trọn chữ gốc + đủ chỗ cho chữ mới."""
    y0 = int(((top - 0.012) - 0.02) / 0.96 * 1280)
    y1 = int(((bottom + 0.012) - 0.02) / 0.96 * 1280)
    if y1 - y0 < 96:
        mid = (y0 + y1) // 2
        y0, y1 = mid - 48, mid + 48
    if y0 < 0:                       # dải sát mép trên/dưới: trượt cửa sổ vào trong (cắt bớt thì dải < 80px, boxblur
        y0, y1 = 0, y1 - y0          # chroma 4:2:0 từ chối bán kính 20 -> cả lần dựng lỗi, rà soát 13/11/2026)
    if y1 > 1280:
        y0, y1 = max(0, y0 - (y1 - 1280)), 1280
    return y0, max(2, y1 - y0)


def _cover_filter(bands, W: int = 720, H: int = 1280) -> str:
    """Che từng dải chữ gốc: làm mờ mạnh + phủ tối 45% (nhìn như nền phụ đề, không lộ chữ cũ)."""
    out, k = "", H / 1280
    for i, (top, bottom) in enumerate(bands):
        y, h = band_to_output(top, bottom)
        y, h = int(y * k), int(h * k)
        r = max(1, min(int(20 * k), h // 4 - 1))        # boxblur: bán kính sắc độ (h/2 chiều cao) phải ≤ h/4 - 1
        out += (f",split=2[cv{i}a][cv{i}b];[cv{i}b]crop={W}:{h}:0:{y},boxblur={r}:4[cv{i}bl];"
                f"[cv{i}a][cv{i}bl]overlay=0:{y},drawbox=x=0:y={y}:w={W}:h={h}:color=black@0.45:t=fill")
    return out


# Giọng TTS nghe "máy" vì: quá khô (như phòng cách âm), phụ âm s/x chói, âm lượng đều tăm tắp,
# tách rời không gian cảnh quay. Chuỗi này: bỏ ù thấp -> ấm vùng 230Hz -> bớt chói 3.8kHz ->
# khử xì (de-ess) -> nén nhẹ cho đều như thu micro thật -> phản xạ phòng bếp rất ngắn.
VOICE_FX = ("highpass=f=75,equalizer=f=230:t=q:w=1.1:g=1.8,equalizer=f=3800:t=q:w=1.6:g=-2.2,"
            "deesser=i=0.35:m=0.5:f=0.5,acompressor=threshold=0.1:ratio=2.5:attack=12:release=140:makeup=1.3,"
            "aecho=0.9:0.55:13|22|34:0.10|0.07|0.04,")


def _voice_fx() -> str:
    return VOICE_FX if config.VOICE_HUMANIZE != "0" else ""


GATE_PAD, GATE_MERGE, GATE_RAMP = 0.2, 0.8, 0.15


GATE_FLOOR = 0.0   # KHÔNG giữ lớp nền khi người gốc nói: đo được lọc 3kHz ở 12% vẫn để máy nghe chép nguyên câu gốc


def _gate_windows(speech: list) -> list:
    """Khoảng người gốc nói (đệm 0.2s), gộp các khoảng cách nhau < 0.8s để tiếng nền không chập chờn."""
    out = []
    for a, b in sorted((max(0.0, a - GATE_PAD), b + GATE_PAD) for a, b in speech[:2000]):
        if out and a - out[-1][1] < GATE_MERGE:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return out


def _gate_w(speech: list) -> str:
    """Biểu thức 0..1 theo thời gian: 1 khi người gốc nói, lên/xuống dần trong 0.15s (không cắt phụt)."""
    r = GATE_RAMP
    terms = "+".join(f"clip((t-{a:.2f}+{r})/{r},0,1)*clip(({b:.2f}+{r}-t)/{r},0,1)" for a, b in _gate_windows(speech))
    return f"min(1,{terms or '0'})"


def _gate_chain(speech: list, src: str) -> str:
    """Tiếng nền khi KHÔNG tách giọng AI: lúc người gốc nói thì tắt dần phần đầy đủ, chỉ giữ lớp tiếng xèo đã lọc
    dưới 3kHz (dải giọng người) ở mức GATE_FLOOR; hết nói thì hiện lại dần. Bản cũ tắt/bật 0<->1 tức thì:
    đo được 202 lần nhảy ≥15dB/0.1s trong 95s, có quãng im bặt -> nghe khựng như video bị lag."""
    w = _gate_w(speech)
    return (f"{src}aformat=sample_rates=44100:channel_layouts=stereo,asplit=2[gf][gh];"
            f"[gf]volume='1-{w}':eval=frame[gf2];"
            f"[gh]highpass=f=3000,highpass=f=3000,volume='{GATE_FLOOR}*{w}':eval=frame[gh2];"
            "[gf2][gh2]amix=inputs=2:normalize=0,")


OST_LEVEL = {"orig": 1.0, "both": 0.35}     # mức tiếng gốc: giữ nguyên / lót nhỏ dưới giọng đọc mới


OST_RAMP = 0.2


def ost_windows(segs: list, out_dur: float) -> list:
    """Đoạn đánh dấu giữ tiếng gốc -> [(đầu, cuối, mức)]: 'orig' = chỉ tiếng gốc (cả lời người gốc), không đọc
    lời mới; 'both' = đọc lời mới, tiếng gốc lót nhỏ phía dưới. Cuối = đầu đoạn kế (hoặc hết video)."""
    out = []
    for k, sg in enumerate(segs):
        lvl = OST_LEVEL.get(sg.get("ost", "new"))
        if lvl is None:
            continue
        a = float(sg["start"])
        b = float(segs[k + 1]["start"]) if k + 1 < len(segs) else out_dur
        if min(b, out_dur) > a:
            out.append((round(a, 2), round(min(b, out_dur), 2), lvl))
    return out


def _trap(a: float, b: float, r: float = OST_RAMP) -> str:
    """1 trong [a, b], vuốt lên/xuống r giây NẰM TRONG cửa sổ (không lấn sang đoạn giọng mới hai bên)."""
    r = max(0.01, min(r, (b - a) / 2))
    return f"clip((t-{a:.2f})/{r:.3f},0,1)*clip(({b:.2f}-t)/{r:.3f},0,1)"


def _ost_level_expr(wins: list) -> str:
    """Biểu thức âm lượng tiếng gốc theo thời gian (vuốt 0.2s ở hai đầu mỗi cửa sổ)."""
    return "min(1," + ("+".join(f"{lvl}*{_trap(a, b)}" for a, b, lvl in wins) or "0") + ")"


def _ost_any_expr(wins: list) -> str:
    return "min(1," + ("+".join(_trap(a, b) for a, b, _ in wins) or "0") + ")"


def out_fps(src_fps: float) -> float:
    """Tốc độ khung đầu ra: nguồn ≤30 giữ nguyên (không chèn khung lặp); >30 chia ĐỀU
    (50->25, 60->30, 48->24). Ép 50->30 phải lấy khung nhịp 2-1-2-2-1 -> chuyển động giật."""
    if not src_fps or src_fps <= 0 or src_fps > 240:
        return 30.0
    if src_fps <= 30.5:
        return round(src_fps, 3)
    n = math.ceil(src_fps / 30.0 - 0.02)
    if n > 1 and src_fps / n < 24:             # 31-45 fps: chia đôi còn 15-22 fps giật hơn là giữ nguyên
        n -= 1
    return round(src_fps / n, 3)


def kelvin_gains(kelvin: float, mix: float) -> tuple:
    """Hệ số nhân từng kênh R, G, B của filter colortemperature (công thức kelvin2rgb của FFmpeg, pl=0):
    out = c * (1 - mix + mix * k_c). Với pl=0 nó chỉ là nhân hằng số từng kênh."""
    k = kelvin / 100.0
    sat = lambda v: min(1.0, max(0.0, v))   # noqa: E731
    if k <= 66:
        rgb = [1.0, sat(0.39008157876901960784 * math.log(k) - 0.63184144378862745098)]
    else:
        t = max(k - 60.0, 0.0)
        rgb = [sat(1.29293618606274509804 * t ** -0.1332047592), sat(1.12989086089529411765 * t ** -0.0755148492)]
    rgb.append(1.0 if k >= 66 else 0.0 if k <= 19 else sat(0.54320678911019607843 * math.log(k - 10) - 1.19625408914))
    return tuple(1 - mix + mix * c for c in rgb)


def warm_filter(kelvin: float = 6000, mix: float = 0.35) -> str:
    """Làm ấm màu: KẾT QUẢ NHƯ colortemperature=temperature=6000:mix=0.35 (đo SSIM 0.99987, PSNR 55dB) nhưng bằng
    bảng tra 1 chiều lutrgb thay vì tính số thực từng điểm ảnh: phần lọc hình 1080p nhanh hơn ~20% trên 1 lõi."""
    gains = kelvin_gains(kelvin, mix)
    parts = [f"{ch}='clip(val*{g:.8f}+0.5\\,0\\,255)'" for ch, g in zip("rgb", gains) if abs(g - 1) > 1e-6]
    return ("lutrgb=" + ":".join(parts) + ",") if parts else ""


# Bộ màu theo kênh (BRAND_LOOK, bản 42). "goc" = công thức đã duyệt ở dưới, giữ y nguyên.
LOOKS = {
    # ấm mộc: ấm hơn, bớt xanh ở vùng tối, tương phản vừa
    "am_moc": ("hqdn3d=1.2:1.2:3:3,eq=contrast=1.06:brightness=0.008:saturation=1.02,vibrance=intensity=0.16,"
               "colorbalance=rs=0.03:bs=-0.03:rm=0.025:bm=-0.025," + "{warm}"),
    # tươi sáng: sáng + màu tươi, trắng sạch (không ám vàng)
    "tuoi_sang": "hqdn3d=1.2:1.2:3:3,eq=contrast=1.04:brightness=0.03:saturation=1.08:gamma=1.03,vibrance=intensity=0.25,",
    # điện ảnh: tối xanh lơ, sáng cam, tương phản cao, viền tối nhẹ
    "dien_anh": ("hqdn3d=1.2:1.2:3:3,eq=contrast=1.10:brightness=-0.008:saturation=0.94,"
                 "colorbalance=rs=-0.03:bs=0.035:rh=0.045:bh=-0.04,vignette=angle=PI/5,"),
}
GRAIN = "noise=c0s=5:c0f=t+u"            # hạt phim rất nhẹ, chỉ kênh sáng; chỉ ở 1080p (720p bị nén thành khối)
# BRAND_LOOK=auto (bản 1.0.0): tông đã chọn cho job đang chạy (rmvideo/media/autolook.py). Theo ngữ cảnh của task: mỗi
# job một task riêng nên không lẫn tông giữa các job; chưa chọn thì dùng tông mặc định trước 1.0.0.
AUTO_LOOK: ContextVar[str] = ContextVar("auto_look", default="")


def look_name() -> str:
    """Tông màu đang dùng: BRAND_LOOK, hoặc tông đã tự chọn cho video này khi BRAND_LOOK=auto."""
    name = config.BRAND_LOOK or "goc"
    return (AUTO_LOOK.get() or "tuoi_sang") if name == "auto" else name


def look_chain(mode: str, W: int, H: int, src_w: int = 0, src_h: int = 0, grain: bool = True,
               zoom: float = 1.0, part: str = "all", anchor_y: float = 0.5) -> str:
    """Hình đẹp hơn bản gốc (dùng chung cho video và ảnh bìa): cắt 4% viền -> khử nhiễu nén (hqdn3d) + tương
    phản/sáng nhẹ + vibrance (tăng màu nhạt, không làm cháy màu da) + ấm nhẹ cho món ăn, và scale lanczos (thứ tự
    tuỳ nguồn nhỏ hay lớn) -> làm nét (cas khi QUALITY=high, không thì unsharp)."""
    cook = mode == "cook"
    # Công thức màu GIỮ NGUYÊN bản người dùng đã duyệt: vibrance chỉ tăng màu vùng còn nhạt, chừa vùng đã đậm
    # (món chiên vàng cam). Bản thử eq saturation=1.2 tăng đều mọi thứ -> gà rang muối cam loang, bị chê -> bỏ.
    look = ("hqdn3d=1.2:1.2:3:3,"
            f"eq=contrast=1.05:brightness=0.012:saturation={'1.06' if cook else '1.03'},"
            f"vibrance=intensity={'0.2' if cook else '0.1'},"
            + (warm_filter(6000, 0.35) if cook else ""))
    preset = LOOKS.get(look_name())
    if preset:
        look = preset.replace("{warm}", warm_filter(5400, 0.4) if cook else "")
    fr = framing.current(src_w, src_h)         # khung dọc theo nội dung (1.1.2): bỏ dải đen, cửa sổ 9:16, nền mờ
    pre = framing.pre_crop(fr)
    if fr:
        src_w, src_h = fr["box"][2], fr["box"][3]
    size = (framing.pad_graph(W, H) if fr.get("pad") else
            f"scale={W}:{H}:force_original_aspect_ratio=increase:flags=lanczos,crop={W}:{H},")
    # Nguồn NHỎ hơn đầu ra (vd 360x640 -> 720x1280): khử nhiễu + chỉnh màu ở kích thước gốc rồi mới phóng to
    # (ít điểm ảnh hơn 4 lần; khử nhiễu trên điểm ảnh thật tốt hơn trên điểm ảnh nội suy).
    keep = 0.96 / max(zoom, 1.0)               # zoom > 1: đẩy cận (kế hoạch dựng) ngay ở lần cắt viền, không tốn thêm
    upscale = bool(src_w and src_h) and max(W / (src_w * keep), H / (src_h * keep)) > 1.05
    sharpen = "cas=strength=0.5" if config.QUALITY == "high" else "unsharp=3:3:0.6:3:3:0"
    # cas: làm nét thích ứng, đẹp nhất, tốn ~2.7x unsharp; unsharp kênh sáng: SSIM 0.984-0.988 so với bản cas
    tail = ("," + GRAIN) if grain and config.BRAND_GRAIN == "1" and H >= 1900 else ""
    crop = "crop=in_w*0.96:in_h*0.96," if abs(zoom - 1.0) < 1e-6 else f"crop=in_w*{keep:.4f}:in_h*{keep:.4f},"
    if anchor_y != 0.5 and abs(zoom - 1.0) >= 1e-6:     # cận neo đáy (cảnh người gốc nói vào máy): cắt mất miệng, giữ tay
        crop = f"crop=in_w*{keep:.4f}:in_h*{keep:.4f}:(in_w-out_w)/2:(in_h-out_h)*{anchor_y:.3f},"
    if part == "geo":                          # chỉ cắt khung + đổi cỡ (màu chạy chung sau khi ghép khúc: shared_look)
        return (pre + crop + size).rstrip(",")
    if part == "color":                        # khử nhiễu + màu + làm nét, trên hình đã đúng cỡ
        return look + sharpen + tail
    return pre + crop + (look + size if upscale else size + look) + sharpen + tail


def shared_look(plan, W: int, H: int, src_w: int, src_h: int) -> bool:
    """Kế hoạch dựng nhiều khúc + nguồn đủ lớn (không phải phóng to ở khúc nào): mỗi khúc chỉ cắt khung + đổi cỡ, khử
    nhiễu / màu / làm nét chạy MỘT lần sau khi ghép. Bản 49: mỗi khúc một chuỗi màu (hqdn3d giữ khung trước, unsharp...)
    ở 1080x1920 -> 36 khúc ffmpeg ngốn ~1,1 GB RAM (bản thường 0,34 GB); máy Botkeep 2 GB giết ffmpeg giữa chừng.
    Nguồn nhỏ (phải phóng to) giữ cách cũ: chỉnh màu trên điểm ảnh thật rồi mới phóng, ít điểm ảnh nên tốn ít RAM."""
    if plan is None or not (src_w and src_h) or not plan.pieces:
        return False
    keep = 0.96 / max(1.0, max(p.zoom for p in plan.pieces))
    return max(W / (src_w * keep), H / (src_h * keep)) <= 1.05


TEASER_DUR = 2.0          # đoạn mở đầu: cảnh thành phẩm chiếu trước kèm câu hook (bản 29: 3 giây; 1.4.0: 2 giây)
TEASER_LEAD = 0.5         # bắt đầu trước khung AI chọn chừng này (cùng cảnh): thấy trọn động tác cắn / rưới sốt


TEASER_ZOOM = 0.06        # đẩy cận 6% trong đoạn mở đầu (ảnh tĩnh: x1.7)


TEASER_STILL_ZOOM = 1.7


def teaser_window(t: float, cuts: list, end: float, dur: float = TEASER_DUR, lead: float = 0.0) -> tuple:
    """(giây bắt đầu, ảnh tĩnh?) của đoạn mở đầu dài dur giây trong CÙNG cảnh với khung t (thời gian video gốc).
    Đủ chỗ thì bắt đầu tại t - lead (không lùi qua đầu cảnh): khung AI chọn thường là giữa động tác (đang cắn, đang kéo
    sợi), lùi một chút để thấy trọn động tác; cảnh đủ dài nhưng t sát cuối cảnh thì lùi về trước; cảnh ngắn hơn dur thì
    đứng hình tại t (đẩy cận)."""
    prev = max([c for c in cuts if c <= t + 0.05], default=0.0)
    nxt = min([c for c in cuts if c > t + 0.05] + [end])
    s0 = min(t, max(t - lead, prev + 0.15 if prev > 0 else 0.0))
    if nxt - s0 >= dur + 0.15:
        return round(s0, 3), False
    if nxt - prev >= dur + 0.3:
        return round(max(prev + 0.15, nxt - dur - 0.15), 3), False
    return round(t, 3), True


HOOK_TITLE_UNTIL = 3.3      # chữ hook to hiện tới chừng này khi không có đoạn mở đầu (renderer.hook_title_end)


def montage_windows(edit: dict | None, teaser: dict | None = None) -> list[tuple[float, float]]:
    """Quãng điểm danh nguyên liệu (kế hoạch dựng mạnh) trên trục video ra, đã cộng đoạn mở đầu."""
    T = float(teaser.get("dur") or 0.0) if teaser else 0.0
    return [(float(x["t"]) + T, float(x["t"]) + T + float(x.get("dur") or 0.0))
            for x in (edit or {}).get("texts") or [] if x.get("kind") == "montage"]


def subtitle_texts(segs: list, teaser: dict | None = None, title_shown: bool = False,
                   quiet: list | None = None) -> list:
    """Chữ phụ đề của từng đoạn: đoạn giữ tiếng gốc không có chữ; chữ hook to đang hiện trên màn hình (BRAND_INTRO)
    thì câu hook không hiện phụ đề nữa (hai lớp chữ chồng nhau che mất món). Bản 1.0.1: cả khi không có đoạn mở đầu
    (title_shown) — job 1 hiện cùng lúc «MỰC ĐÔNG HẤP KHÔNG RÃ ĐÔNG» và phụ đề «Mực đông hấp kiểu này ngon ghê» —
    với điều kiện câu hook dứt trong lúc chữ hook còn hiện (câu dài hơn thì vẫn cần phụ đề)."""
    on = config.BRAND_INTRO != "0"

    def hook_hidden(s: dict) -> bool:
        if not on or float(s.get("start", 1.0)) >= 0.05:
            return False
        if teaser:
            return True
        end = float(s.get("start", 0.0)) + float(s.get("slot") or s.get("span") or 99.0)
        return title_shown and end <= HOOK_TITLE_UNTIL + 0.3

    def in_quiet(s: dict) -> bool:
        # 1.1.2 job 2 (20/11): trong đoạn điểm danh nguyên liệu, thẻ «1/4 trái khóm» đã hiện từng món; phụ đề đọc cả câu
        # lặp lại đúng chữ đó ngay bên dưới mà lệch nhịp (thẻ «4 muỗng đường» trong lúc phụ đề còn «50g me cục») -> ẩn
        st = float(s.get("start", -1.0))
        return any(a - 0.2 <= st < b for a, b in quiet or [])

    return ["" if s.get("ost") == "orig" or (k == 0 and hook_hidden(s)) or in_quiet(s) else s["text"]
            for k, s in enumerate(segs)]


def _plan_video(plan, mode: str, W: int, H: int, src_w: int, src_h: int, fps: float, side_inputs, lead) -> str:
    if shared_look(plan, W, H, src_w, src_h):
        return (edl.video_graph(plan, lambda z, ay=0.5: look_chain(mode, W, H, src_w, src_h, zoom=z, part="geo",
                                                                   anchor_y=ay), fps, W, H,
                                side_inputs=side_inputs, lead=lead)
                + "," + look_chain(mode, W, H, src_w, src_h, part="color"))
    return edl.video_graph(plan, lambda z, ay=0.5: look_chain(mode, W, H, src_w, src_h, zoom=z, anchor_y=ay), fps, W, H,
                           side_inputs=side_inputs, lead=lead)


# Nhạc lót dưới lời đọc (VOICE_BED, bản 1.0.0): tự hạ khi giọng đọc vang lên. Đo trên video gà 60 giây: quãng lặng nhạc
# thấp hơn giọng ~13 dB (renderer.BED_BELOW), lúc đang đọc hạ thêm ~9 dB (ngang tiếng nền đã hạ dưới giọng). Thử
# hạ theo cả tiếng nền (xèo xèo): nhạc gần như mất hẳn trong video nấu ăn -> bỏ. Vào / ra chậm để nhạc không «thở».
VOICE_BED_DUCK = "sidechaincompress=threshold=0.05:ratio=3:attack=150:release=900"


def _voice_bed_chain(bed: dict, out_dur: float, ost: list) -> str:
    """[đầu vào nhạc] -> [bed0]: đúng độ dài video, chỉnh mức (gain_db), vào 1 giây / ra 2 giây, tắt trong các quãng
    giữ tiếng gốc (tiếng gốc ở đó đã đủ, thêm nhạc thì rối)."""
    mute = f",volume='1-{_ost_any_expr(ost)}':eval=frame" if ost else ""
    # highpass 150 Hz: bỏ bass của nhạc (chừa chỗ cho giọng; bass to đẩy đỉnh tiếng lên bộ giới hạn làm cả video nhỏ đi
    # ~2 dB, đo trên bài Vibe Ace), lowpass 9 kHz: nhạc lùi ra sau, không chen tiếng «s» của giọng đọc
    return (f"[{int(bed['idx'])}:a]aformat=sample_rates=44100:channel_layouts=stereo,atrim=0:{out_dur:.2f},"
            f"asetpts=PTS-STARTPTS,highpass=f=150,lowpass=f=9000,volume={float(bed.get('gain_db') or 0.0):.1f}dB,"
            "afade=t=in:st=0:d=1.0,"
            f"afade=t=out:st={max(0.0, out_dur - 2.0):.2f}:d=2.0{mute}[bed0];")


def build_filter(mode: str, out_dur: float, ambient: bool, ass_path: str | None,
                 cover_bands=None, W: int = 720, H: int = 1280,
                 ambient_src: str = "[0:a]", speech_gate=None,
                 fps: float = 30.0, src_w: int = 0, src_h: int = 0, stretch: float = 1.0,
                 ost=None, orig_audio: bool = True, bed: bool = False, teaser: dict | None = None,
                 edit=None, side_inputs: dict | None = None, side_audio: dict | None = None, tail: float = 0.0,
                 voice_bed: dict | None = None) -> str:
    """Hình: look_chain (fps=30 ĐẦU TIÊN: nguồn TikTok HD thường 50-60fps, lọc trước khi bớt khung là phí 67-100%)
    + che dải chữ gốc + phụ đề mới. Tiếng: giọng mới + tiếng nền (tách giọng / cổng) + tiếng gốc giữ lại.
    teaser: đoạn mở đầu {"iv": đầu vào hình (đã tua tới cảnh món xong), "ia": đầu vào tiếng nền của cảnh đó hoặc
    None, "dur": giây, "still": ảnh tĩnh} nối TRƯỚC video chính; mọi mốc (phụ đề, cổng tiếng, cửa sổ tiếng gốc) do
    caller đưa vào đã tính cả đoạn mở đầu.
    voice_bed: nhạc lót dưới lời {"idx": đầu vào, "gain_db": mức} (VOICE_BED) hoặc None."""
    tz = teaser if teaser and teaser.get("dur") else None
    T = float(tz["dur"]) if tz else 0.0
    if cover_bands:                              # khung dọc theo nội dung: dải chữ gốc đổi sang khung ra (trước khi đẩy cận)
        cover_bands = framing.map_bands(list(cover_bands), framing.current(src_w, src_h))
    plan = edit                                  # rmvideo.media.edl.EditPlan (REMAKE_STYLE) hoặc None = như cũ
    # stretch > 1: làm chậm hình ngay trong lần render này (trước đây stretch() mã hoá cả video một lần riêng)
    slow = f"setpts=PTS*{stretch:.4f}," if abs(stretch - 1) > 1e-3 and plan is None else ""
    orig_src = "[0:a]"
    pre_audio = ""
    if plan is not None:
        # tiếng gốc / tiếng nền đi theo đúng các khúc của kế hoạch (cắt, tua nhanh, clip phụ)
        if orig_audio and [w for w in (ost or []) if w[1] > w[0]]:
            pre_audio += edl.audio_graph(plan, "[0:a]", "[orgE]", tag="o")
            orig_src = "[orgE]"
        if mode == "cook" and ambient and not bed:
            pre_audio += edl.audio_graph(plan, ambient_src, "[ambE]", side_audio=side_audio, tag="b")
            ambient_src = "[ambE]"
        if cover_bands:
            cover_bands = edl.zoomed_bands(list(cover_bands), {(p.zoom, p.ay) for p in plan.pieces})
    if slow:
        ambient_src += f"atempo={1 / stretch:.4f},"          # tiếng nền chậm theo hình (tiếng gốc hoặc đã tách giọng)
        orig_src += f"atempo={1 / stretch:.4f},"
    if tz:
        orig_src += f"adelay={int(round(T * 1000))}:all=1,"   # tiếng gốc của video chính lùi sau đoạn mở đầu
    ost = [w for w in (ost or []) if w[1] > w[0]] if orig_audio else []
    # tiếng gốc NGUYÊN BẢN (cả lời người gốc) chỉ trong các cửa sổ được đánh dấu giữ tiếng gốc
    ost_chain = (f"{orig_src}aformat=sample_rates=44100:channel_layouts=stereo,"
                 f"volume='{_ost_level_expr(ost)}':eval=frame[ost];") if ost else ""
    look = look_chain(mode, W, H, src_w, src_h)
    if tz:
        # cảnh món đã xong chiếu trước: cùng chuỗi màu với video, đẩy cận nhẹ cho có nhịp (ảnh tĩnh đẩy mạnh hơn),
        # rồi nối thẳng vào video chính. Đầu vào riêng đã tua sẵn: không bắt FFmpeg giữ hàng nghìn khung chờ nối.
        z = TEASER_ZOOM * (TEASER_STILL_ZOOM if tz.get("still") else 1.0)
        # màu chạy chung sau khi ghép (shared_look): đoạn mở đầu chỉ cắt khung + đổi cỡ, khỏi chỉnh màu hai lần
        tz_look = look_chain(mode, W, H, src_w, src_h, part="geo") if shared_look(plan, W, H, src_w, src_h) else look
        v = (f"[{tz['iv']}:v]"
             + (f"trim=end_frame=1,tpad=stop_mode=clone:stop_duration={T + 0.2:.2f}," if tz.get("still") else "")
             + f"setpts=PTS-STARTPTS,fps={fps:g},{tz_look},"
             f"scale=w='trunc({W}*(1+{z:.3f}*t/{T:.2f})/2)*2':h=-2:eval=frame,"
             f"crop={W}:{H}:x='(trunc({W}*(1+{z:.3f}*t/{T:.2f})/2)*2-{W})/2'"
             f":y='(trunc({H}*(1+{z:.3f}*t/{T:.2f})/2)*2-{H})/2',setsar=1,"
             f"trim=duration={T:.3f}[tzv];"
             + (_plan_video(plan, mode, W, H, src_w, src_h, fps, side_inputs, ["[tzv]"]) if plan is not None else
                f"[0:v]{slow}fps={fps:g},{look},setsar=1[mnv];[tzv][mnv]concat=n=2:v=1:a=0"))
    elif plan is not None:
        v = _plan_video(plan, mode, W, H, src_w, src_h, fps, side_inputs, None)
    else:
        v = f"[0:v]{slow}fps={fps:g}," + look
    if tail > 0:                                 # màn kết nối thêm: giữ khung cuối (phụ đề / che chữ vẫn vẽ lên)
        v += f",tpad=stop_mode=clone:stop_duration={tail:.3f}"
    v += _cover_filter(cover_bands or [], W, H)
    if ass_path:
        v += f",subtitles=filename={ass_path}:fontsdir={ff.ASSETS_DIR}"
    v += "[v];" + pre_audio
    vb = voice_bed if voice_bed and voice_bed.get("idx") is not None and not bed else None
    if bed:
        # video KHÔNG LỜI: lớp nền đã trộn sẵn (nhạc nền + tiếng gốc, music_bed) là tiếng chính, không có giọng đọc;
        # không qua lọc giọng (EQ/nén/vang làm méo nhạc), không làm chậm (nhạc giữ đúng nhịp, music_bed đã tính)
        return v + (f"[2:a]aformat=sample_rates=44100:channel_layouts=stereo,{LOUDNORM},{AOUT},"
                    f"apad=whole_dur={out_dur:.2f}[a]")
    if mode == "cook" and ambient:
        # highpass 3kHz giữ tiếng xèo xèo; sidechaincompress tự hạ tiếng nền khi giọng đọc
        # vang lên (ducking như video chuyên nghiệp); loudnorm chuẩn hóa âm lượng -16 LUFS
        pre = ""
        if tz:
            # tiếng nền của đoạn mở đầu: tiếng xèo/giòn của chính cảnh đó (bản đã tách giọng); không có bản tách
            # giọng thì im (tiếng gốc cảnh đó có thể còn lời người gốc), rồi tới tiếng nền của video chính
            pre = ((f"[{tz['ia']}:a]aformat=sample_rates=44100:channel_layouts=stereo,asetpts=PTS-STARTPTS,"
                    f"apad=whole_dur={T:.3f},atrim=0:{T:.3f}[tza];") if tz.get("ia") is not None else
                   f"anullsrc=r=44100:cl=stereo,atrim=0:{T:.3f}[tza];")
            pre += (f"{ambient_src}aformat=sample_rates=44100:channel_layouts=stereo[mna];"
                    "[tza][mna]concat=n=2:v=0:a=1[ambx];")
            ambient_src = "[ambx]"
        ins, ws = ["[vo]", "[ambd]"] + (["[ost]"] if ost else []), ["1", "0.5"] + (["1"] if ost else [])
        if vb:                                    # nhạc lót: tự hạ khi giọng đọc vang lên
            ins, ws = ins + ["[bedd]"], ws + ["1"]
        a = (
            pre + "[1:a]aformat=sample_rates=44100:channel_layouts=stereo," + _voice_fx()
            + ("asplit=3[vo][sc][bk1];" if vb else "asplit=2[vo][sc];")
            + (_gate_chain(speech_gate, ambient_src) if speech_gate else
               f"{ambient_src}aformat=sample_rates=44100:channel_layouts=stereo,")
            + "volume=0.8"
            # trong cửa sổ giữ tiếng gốc thì tắt lớp tiếng nền (tiếng gốc đã có tiếng nền, tránh nghe gấp đôi)
            + (f",volume='1-{_ost_any_expr(ost)}':eval=frame" if ost else "") + "[amb];"
            "[amb][sc]sidechaincompress=threshold=0.02:ratio=6:attack=100:release=500[ambd];"
            + (_voice_bed_chain(vb, out_dur, ost) + f"[bed0][bk1]{VOICE_BED_DUCK}[bedd];" if vb else "")
            + ost_chain
            + f"{''.join(ins)}amix=inputs={len(ins)}:duration=longest:weights='{' '.join(ws)}',"
            + f"{LOUDNORM},{AOUT}[a]"
        )
    elif ost:
        # giọng mới + tiếng gốc trong các cửa sổ giữ tiếng gốc
        fx = _voice_fx().rstrip(",") or "anull"
        a = (
            f"[1:a]aformat=sample_rates=44100:channel_layouts=stereo,{fx}"
            + ("[vo0];[vo0]asplit=2[vo][bk1];" + _voice_bed_chain(vb, out_dur, ost) + f"[bed0][bk1]{VOICE_BED_DUCK}[bedd];"
               if vb else "[vo];") + ost_chain
            + ("[vo][ost][bedd]amix=inputs=3:duration=longest:normalize=0," if vb else
               "[vo][ost]amix=inputs=2:duration=longest:normalize=0,")
            + f"{LOUDNORM},{AOUT},apad=whole_dur={out_dur:.2f}[a]"
        )
    elif vb:
        # chỉ giọng AI + nhạc lót (tự hạ khi đang đọc)
        a = (
            "[1:a]aformat=sample_rates=44100:channel_layouts=stereo," + _voice_fx() + "asplit=2[vo][bk1];"
            + _voice_bed_chain(vb, out_dur, []) + f"[bed0][bk1]{VOICE_BED_DUCK}[bedd];"
            "[vo][bedd]amix=inputs=2:duration=longest:normalize=0,"
            f"{LOUDNORM},{AOUT},apad=whole_dur={out_dur:.2f}[a]"
        )
    else:
        # chỉ giọng AI; apad hữu hạn đệm im lặng tới hết video
        # (apad vô hạn + -shortest từng gây treo/OOM, nên luôn pad có giới hạn và cắt bằng -t)
        a = (
            "[1:a]aformat=sample_rates=44100:channel_layouts=stereo," + _voice_fx() +
            f"{LOUDNORM},{AOUT},apad=whole_dur={out_dur:.2f}[a]"
        )
    return v + a
