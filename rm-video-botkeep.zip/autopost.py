"""🤖 Tự động đăng: lấy NGẪU NHIÊN một video (không bao giờ lặp lại) từ kênh nguồn Facebook và/hoặc TikTok (ô tick
AUTO_PLATFORMS; tick cả hai thì xen kẽ hai nền tảng) -> làm lại như job thường -> đăng lên Fanpage của bạn qua Graph
API chính thức, HẸN ĐÚNG GIỜ VÀNG; mặc định 2 video/ngày.

- Kênh TikTok: yt-dlp đọc được danh sách ~30 video mới nhất của kênh (khác Facebook). Chống trùng: ngoài danh sách
  video đã dùng, video mới còn được so độ dài + chú thích với mọi video đã làm (cùng một video người gốc đăng ở cả
  Facebook lẫn TikTok, hoặc đăng lại, thì không làm lần hai).

- Danh sách video của kênh: trang Reels + Video của kênh (không cần đăng nhập Facebook lấy được ~10 video mới nhất mỗi
  tab; yt-dlp không liệt kê được kênh Facebook). Video đã dùng ghi vào autopost.json nên không bao giờ dùng lại; kênh
  hết video mới thì chờ kênh đăng thêm (kiểm lại mỗi 6 giờ).
- Làm video: job bình thường (source="auto", không dừng chờ duyệt). Chỉ thêm job khi hàng đợi TRỐNG: video bạn tự gửi
  luôn được làm trước. Máy chậm (~40 phút/video) nên làm TRƯỚC và hẹn giờ đăng phía Facebook (giữ sẵn ~1 ngày).
- Đăng: video <= 90s -> Reels API (start -> rupload -> finish, video_state=SCHEDULED); dài hơn -> /{page}/videos
  (published=false + scheduled_publish_time). Facebook yêu cầu giờ hẹn cách hiện tại > 10 phút.
- Giờ vàng: chưa có số liệu thì dùng 20:30 và 11:30 (giờ Việt Nam: cao điểm tối + trưa của người dùng Facebook VN).
  Mỗi bài sau 24 giờ được đọc lượt xem (video_insights) và cộng vào khung giờ đã đăng; khung nào trung bình cao hơn
  thì được chọn nhiều hơn, thỉnh thoảng thử khung khác (25%) để không bỏ sót giờ tốt hơn. Đặt AUTO_TIMES để cố định.
"""
import asyncio
import hashlib
import json
import logging
import os
import random
import re
import tempfile
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

import aiohttp

import config
import url_guard
from rmvideo.app.flow import dedupe
from rmvideo.domain import recipe
from rmvideo.domain.sources import PLATFORMS, detect_platform, normalize_source, normalize_tiktok  # noqa: F401

VN = timezone(timedelta(hours=7))           # Việt Nam không đổi giờ mùa hè
BASE = os.path.dirname(os.path.abspath(__file__))
STATE_FILE = os.environ.get("AUTOPOST_STATE") or os.path.join(BASE, "autopost.json")
API_VER = os.environ.get("FB_GRAPH_VERSION", "v27.0")
GRAPH = "https://graph.facebook.com"
GRAPH_VIDEO = "https://graph-video.facebook.com"
RUPLOAD = "https://rupload.facebook.com"
REEL_MAX = 90                  # Reels API nhận 3-90 giây
RESUMABLE_MIN = 40 << 20       # video thường nặng hơn mức này: gửi từng khúc (start/transfer/finish); gửi một lần bị HTTP 413
LEAD = 15 * 60                 # hẹn giờ phải > 10 phút sau hiện tại (Graph API); chừa 15 phút
HORIZON = 36 * 3600            # làm sẵn video cho các khung giờ trong 36 giờ tới
LIST_TTL = 6 * 3600            # danh sách video của kênh: đọc lại sau 6 giờ
MIN_GAP_H = 3                  # hai khung giờ trong ngày cách nhau ít nhất 3 giờ
EXPLORE = 0.25                 # xác suất thử một khung giờ khác thay khung yếu nhất
CANDIDATES = ["07:00", "09:30", "11:30", "12:30", "17:30", "19:00", "20:30", "21:30"]
DEFAULT_ORDER = ["20:30", "11:30", "17:30", "21:30", "07:00", "12:30", "19:00", "09:30"]
VIEW_METRICS = ("fb_reels_total_plays", "blue_reels_play_count", "total_video_views", "post_video_views")


SKIP_MARKS = (recipe.NOT_RECIPE, dedupe.DUP_MARK)
SHORT_LABEL = "Bản ngắn"   # job dừng sớm vì lý do của VIDEO NGUỒN: bỏ video, không tính lỗi


class FBError(RuntimeError):
    def __init__(self, msg: str, code: int = 0):
        super().__init__(msg)
        self.code = code


# ---------------- trạng thái ----------------

def load_state(path: str | None = None) -> dict:
    """File hỏng KHÔNG được lặng lẽ thay bằng trạng thái rỗng (mất danh sách video đã dùng -> đăng lại video cũ,
    mất lịch đã hẹn -> hẹn trùng giờ): đổi tên thành .bad, dừng tự động đăng và báo lý do."""
    path = path or STATE_FILE
    try:
        with open(path, encoding="utf-8") as f:
            st = json.load(f)
        if not isinstance(st, dict):
            raise ValueError("nội dung không phải object JSON")
    except FileNotFoundError:
        st = {}
    except (OSError, ValueError) as e:
        try:
            os.replace(path, path + ".bad")
        except OSError:
            pass
        logging.error("autopost.json hỏng (%s), đã đổi tên thành autopost.json.bad", e)
        st = {"paused": f"autopost.json hỏng ({str(e)[:60]}), đã lưu bản cũ thành autopost.json.bad — kiểm tra "
                        "rồi gõ auto_resume (danh sách video đã dùng bắt đầu lại từ đầu)"}
        try:                                    # ghi ngay trạng thái dừng: ai đọc tiếp (vòng chạy, web) cũng thấy
            save_state(dict(st), path)
        except OSError:
            pass
    for k, v in (("used", {}), ("posts", []), ("listing", {}), ("days", {}), ("pending", None), ("paused", ""),
                 ("fails", {}), ("streak", 0), ("manual", [])):
        st.setdefault(k, v)
    if not isinstance(st["manual"], list):
        st["manual"] = []
    return st


def save_state(st: dict, path: str | None = None):
    path = path or STATE_FILE
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


# ---------------- cài đặt ----------------

def _norm_list(raw: str, norm) -> list:
    out = []
    for s in re.split(r"[,\s]+", raw or ""):
        try:
            n = norm(s)
        except ValueError:
            continue
        if n and n not in out:
            out.append(n)
    return out


def sources() -> list:
    """Kênh FACEBOOK nguồn (AUTO_SOURCES)."""
    return _norm_list(config.AUTO_SOURCES, normalize_source)


def tiktok_sources() -> list:
    """Kênh TIKTOK nguồn (AUTO_TIKTOK_SOURCES)."""
    return _norm_list(config.AUTO_TIKTOK_SOURCES, normalize_tiktok)


def platforms() -> list:
    """Nền tảng nguồn đang tick (AUTO_PLATFORMS). Không tick gì / giá trị lạ -> cả hai."""
    got = [p for p in PLATFORMS if p in re.split(r"[,\s]+", (config.AUTO_PLATFORMS or "").lower())]
    return got or list(PLATFORMS)


def all_sources() -> list:
    """[(nền tảng, kênh)] của các nền tảng đang tick."""
    on = platforms()
    return ([("facebook", s) for s in sources()] if "facebook" in on else []) + \
        ([("tiktok", s) for s in tiktok_sources()] if "tiktok" in on else [])


def _source_slot(link: str) -> tuple:
    """(nền tảng, kênh đã chuẩn hoá, tên cài đặt, danh sách hiện có) cho một link kênh. Ném ValueError."""
    plat = detect_platform(link)
    if plat == "tiktok":
        return plat, normalize_tiktok(link), "AUTO_TIKTOK_SOURCES", tiktok_sources()
    if plat == "facebook":
        return plat, normalize_source(link), "AUTO_SOURCES", sources()
    raise ValueError("Dán link kênh đầy đủ: https://www.facebook.com/<tên kênh> hoặc https://www.tiktok.com/@<tên>")


def add_source(link: str) -> tuple:
    """Thêm kênh nguồn ngay trong mục Tự động đăng (bao nhiêu kênh cũng được): nhận ra nền tảng theo link, chuẩn hoá,
    ghi vào AUTO_SOURCES / AUTO_TIKTOK_SOURCES. Trả (nền tảng, kênh)."""
    plat, norm, key, cur = _source_slot(link)
    if norm not in cur:
        config.save_settings({key: ",".join(cur + [norm])})
    return plat, norm


def remove_source(link: str) -> bool:
    try:
        plat, norm, key, cur = _source_slot(link)
    except ValueError:
        return False
    if norm not in cur:
        return False
    rest = [s for s in cur if s != norm]
    config.save_settings({key: ",".join(rest) if rest else "-"})      # "-": bỏ giá trị đè, quay về biến môi trường
    return True


def per_day() -> int:
    try:
        return max(1, min(4, int(config.AUTO_PER_DAY)))          # 4 khung cách nhau >= 3 giờ là tối đa hợp lý
    except (TypeError, ValueError):
        return 2


def fixed_times() -> list:
    return sorted({t for t in re.split(r"[,\s]+", config.AUTO_TIMES or "") if re.fullmatch(r"\d{2}:\d{2}", t)})


def enabled(st: dict | None = None) -> str:
    """"" nếu chạy được; không thì lý do. Có link dán tay đang chờ (st["manual"]) thì không cần kênh nguồn."""
    if config.AUTO_POST != "1":
        return "AUTO_POST đang tắt"
    if not (config.FB_PAGE_ID.strip() and config.FB_PAGE_TOKEN.strip()):
        return "thiếu FB_PAGE_ID / FB_PAGE_TOKEN"
    if not all_sources() and not (st or {}).get("manual"):
        return ("chưa có kênh nguồn cho nền tảng đang tick (AUTO_SOURCES: Facebook, AUTO_TIKTOK_SOURCES: TikTok; "
                f"đang tick: {', '.join(platforms())})")
    return ""


# ---------------- danh sách video của kênh nguồn ----------------

class _AllowedRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        url_guard.check_url(newurl)            # mỗi bước chuyển hướng vẫn phải là nền tảng được phép, không IP nội bộ
        return super().redirect_request(req, fp, code, msg, headers, newurl)


_OPENER = urllib.request.build_opener(_AllowedRedirect)
_VIDEO_ID = re.compile(r'"video_id":"(\d{8,})"')
_VIDEOS_PATH = re.compile(r'facebook\.com/[^/"\s?]+/videos/(?:[^/"\s?]+/)?(\d{8,})')
_OWNER = re.compile(r'"userID":"(\d{5,})"')


def _tab(src: str, tab: str) -> str:
    if "profile.php" in src:
        return src + ("&sk=reels_tab" if tab == "reels" else "&sk=videos")
    return f"{src}/{tab}/"


def _fetch(url: str, opener=None) -> str:
    from yt_dlp.utils.networking import std_headers
    url = url_guard.check_url(url)
    req = urllib.request.Request(url, headers=dict(std_headers))     # header chuẩn của yt-dlp, như khi tải video
    with (opener or _OPENER).open(req, timeout=30) as r:
        final = r.geturl()
        body = r.read(5 << 20).decode("utf-8", "replace")
    if "/login" in urllib.parse.urlsplit(final).path:
        raise RuntimeError("Facebook bắt đăng nhập mới xem được kênh này")
    return body


def parse_listing(reels_html: str, videos_html: str) -> tuple:
    """(danh sách id video theo thứ tự xuất hiện, id chủ kênh hoặc "")."""
    ids = []
    for body in (reels_html, videos_html.replace("\\/", "/")):
        for rx in (_VIDEO_ID, _VIDEOS_PATH):
            for m in rx.finditer(body):
                if m.group(1) not in ids:
                    ids.append(m.group(1))
    owner = _OWNER.search(reels_html) or _OWNER.search(videos_html)
    return ids, owner.group(1) if owner else ""


def list_channel_sync(src: str, fetch=_fetch) -> tuple:
    reels = videos = ""
    errs = []
    for tab in ("reels", "videos"):
        try:
            body = fetch(_tab(src, tab))
        except Exception as e:
            errs.append(str(e)[:120])
            continue
        if tab == "reels":
            reels = body
        else:
            videos = body
    if not (reels or videos):
        raise RuntimeError("; ".join(errs) or "không đọc được kênh")
    return parse_listing(reels, videos)


def list_tiktok_sync(src: str) -> tuple:
    """([{"id", "url", "title", "dur"}], tên kênh): ~30 video mới nhất của kênh TikTok qua yt-dlp (đo thật 13/11/2026:
    trả id, link, chú thích, độ dài)."""
    import yt_dlp
    url_guard.check_url(src)
    from rmvideo.media import fetch
    opts = fetch.ytdlp_base_options({"quiet": True, "no_warnings": True, "noprogress": True, "skip_download": True,
                                     "extract_flat": "in_playlist", "playlistend": 30})   # không extractor generic, proxy
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(src, download=False)
    items = []
    for e in (info or {}).get("entries") or []:
        vid, url = str(e.get("id") or ""), str(e.get("url") or "")
        host = (urllib.parse.urlsplit(url).hostname or "").lower()
        if vid.isdigit() and "/video/" in url and (host == "tiktok.com" or host.endswith(".tiktok.com")):
            items.append({"id": vid, "url": url, "title": (e.get("title") or "")[:200], "dur": e.get("duration")})
    if not items:
        raise RuntimeError("không đọc được video nào của kênh TikTok (kênh riêng tư / bị chặn?)")
    return items, src.rsplit("@", 1)[-1]


# ---------------- chống trùng giữa các nguồn ----------------

def _norm_title(t: str) -> str:
    t = re.sub(r"#\S+|@\S+|https?://\S+", " ", (t or "").lower())
    return " ".join(re.findall(r"\w+", t))[:160]


def same_video(a: dict, b: dict) -> bool:
    """Cùng một video đăng ở hai nơi (Facebook + TikTok, hoặc đăng lại): độ dài lệch <= 1.5s và chú thích giống nhau
    (>= 60% sau khi bỏ hashtag/emoji). Thiếu chú thích thì KHÔNG coi là trùng (chỉ độ dài thì dễ nhầm)."""
    import difflib
    da, db = a.get("dur") or 0, b.get("dur") or 0
    ta, tb = a.get("title") or "", b.get("title") or ""
    if not (da and db and abs(float(da) - float(db)) <= 1.5) or len(ta) < 8 or len(tb) < 8:
        return False
    return difflib.SequenceMatcher(None, ta, tb).ratio() >= 0.6


def duplicate_of(st: dict, key: str, info: dict) -> str:
    """Khoá video đã làm trùng với video sắp lấy (hoặc "")."""
    me = {"dur": info.get("duration") or 0, "title": _norm_title(info.get("title") or "")}
    for k, u in st["used"].items():
        if k != key and not u.get("skip") and same_video(me, u):
            return k
    return ""


def _platform_order(st: dict, rnd: random.Random) -> list:
    """Tick cả hai nền tảng: nền tảng được chọn ÍT hơn trong 6 video gần nhất đi trước (xen kẽ), bằng nhau thì ngẫu
    nhiên. Nền tảng không có kênh nguồn thì bỏ."""
    have = [p for p in platforms() if any(q == p for q, _ in all_sources())]
    recent = sorted((u for u in st["used"].values() if u.get("job")), key=lambda u: u.get("at", 0))[-6:]
    cnt = {p: sum(1 for u in recent if u.get("plat", "facebook") == p) for p in have}
    rnd.shuffle(have)
    return sorted(have, key=lambda p: cnt[p])


# ---------------- giờ vàng ----------------

def _hm(t: str) -> int:
    h, m = t.split(":")
    return int(h) * 60 + int(m)


def _spaced(chosen: list, t: str) -> bool:
    return all(abs(_hm(t) - _hm(c)) >= MIN_GAP_H * 60 for c in chosen)


def slot_stats(st: dict) -> dict:
    """khung giờ -> [lượt xem sau 24 giờ của các bài đã đăng ở khung đó]."""
    out: dict = {}
    for p in st["posts"]:
        if p.get("views") is not None and p.get("slot"):
            out.setdefault(p["slot"], []).append(p["views"])
    return out


def choose_slots(st: dict, n: int, rnd: random.Random) -> list:
    """n khung giờ cho một ngày. Khung đã có >= 2 bài đo được xếp theo lượt xem trung bình; khung chưa đủ số liệu
    được tính bằng mức trung bình chung (để vẫn có lượt thử) và xếp theo thứ tự mặc định; thỉnh thoảng (EXPLORE) đổi
    khung yếu nhất lấy một khung ít được thử nhất."""
    fixed = fixed_times()
    if fixed:
        return fixed[:n] if len(fixed) >= n else fixed
    stats = slot_stats(st)
    known = {k: sum(v) / len(v) for k, v in stats.items() if len(v) >= 2}
    overall = (sum(known.values()) / len(known)) if known else 0.0

    def score(t):
        return (known.get(t, overall), -DEFAULT_ORDER.index(t))
    ranked = sorted(CANDIDATES, key=score, reverse=True)
    chosen = []
    for t in ranked:
        if len(chosen) < n and _spaced(chosen, t):
            chosen.append(t)
    if len(chosen) >= 2 and rnd.random() < EXPLORE:
        tries = sorted((t for t in CANDIDATES if t not in chosen), key=lambda t: (len(stats.get(t, [])), rnd.random()))
        keep = chosen[:-1]
        for t in tries:
            if _spaced(keep, t):
                chosen = keep + [t]
                break
    return sorted(chosen, key=_hm)


def _settings_fp() -> str:
    return f"{','.join(fixed_times())}|{per_day()}"


def _day_busy(st: dict, day: str) -> bool:
    """Ngày đó đã có bài hẹn / video đang làm: giữ nguyên khung giờ của ngày (không hẹn thêm lệch giờ)."""
    times = [p.get("time", 0) for p in st["posts"]] + ([st["pending"].get("slot_ts", 0)] if st.get("pending") else [])
    return any(datetime.fromtimestamp(t, VN).date().isoformat() == day for t in times if t)


def day_slots(st: dict, day: str, rnd: random.Random) -> list:
    """Khung giờ của một ngày, chọn một lần rồi giữ. Đổi AUTO_TIMES / AUTO_PER_DAY thì chọn lại ngay cho các ngày
    chưa có bài nào (trước đây phải chờ ~2 ngày)."""
    d = st["days"].get(day)
    fp = _settings_fp()
    if isinstance(d, dict) and d.get("fp") == fp:
        return d["slots"]
    if d is not None and _day_busy(st, day):
        return d["slots"] if isinstance(d, dict) else d
    st["days"][day] = {"fp": fp, "slots": choose_slots(st, per_day(), rnd)}
    for old in sorted(st["days"])[:-10]:
        st["days"].pop(old, None)
    return st["days"][day]["slots"]


def upcoming_slots(st: dict, now: float, rnd: random.Random, horizon: float = HORIZON) -> list:
    """[(unix time, "HH:MM")] các khung giờ từ now + LEAD tới now + horizon."""
    out = []
    d0 = datetime.fromtimestamp(now, VN).date()
    for k in range(3):
        day = d0 + timedelta(days=k)
        for t in day_slots(st, day.isoformat(), rnd):
            h, m = map(int, t.split(":"))
            ts = datetime(day.year, day.month, day.day, h, m, tzinfo=VN).timestamp()
            if now + LEAD <= ts <= now + horizon:
                out.append((ts, t))
    return sorted(out)


def free_slots(st: dict, now: float, rnd: random.Random) -> list:
    taken = {round(p["time"]) for p in st["posts"] if p.get("time", 0) > now}
    if st.get("pending"):
        taken.add(round(st["pending"].get("slot_ts", 0)))
    return [(ts, t) for ts, t in upcoming_slots(st, now, rnd) if round(ts) not in taken]


# ---------------- Graph API ----------------

def _err(d) -> FBError | None:
    e = (d or {}).get("error") if isinstance(d, dict) else None
    if not e:
        return None
    return FBError(f"Facebook lỗi {e.get('code')}: {e.get('message', '')[:200]}", int(e.get("code") or 0))


async def _json(resp) -> dict:
    try:
        d = await resp.json(content_type=None)
    except Exception:
        d = {"error": {"code": resp.status, "message": (await resp.text())[:200]}}
    err = _err(d)
    if err or resp.status >= 400:
        if resp.status == 413:
            raise FBError("Facebook lỗi HTTP 413: file quá lớn cho một lần gửi (đo thật 13/11/2026 với video 4 phút)", 413)
        raise err or FBError(f"Facebook lỗi HTTP {resp.status}", resp.status)
    return d


def _page(page: str = "", token: str = "") -> tuple:
    """(id Page, token) để đăng: tham số (Fanpage truyện bé, 1.1.0) hay Fanpage kênh bếp trong Cài đặt."""
    return (page or config.FB_PAGE_ID).strip(), (token or config.FB_PAGE_TOKEN).strip()


POST_SCOPES = ("pages_show_list", "pages_read_engagement", "pages_manage_posts")   # đăng Reels / video lên Page


async def check_token(session=None, page: str = "", token: str = "") -> str:
    """Tên Page nếu token ĐĂNG được lên Page đó (mặc định FB_PAGE_ID); không thì ném FBError.
    Trước 1.4.15 chỉ đọc tên Page — token người dùng hay token thiếu quyền cũng đọc được nên «Thử token» báo ✅, rồi đăng
    thật mới lỗi «(#200) Subject does not have permission to post videos on this target» (26/11, Fanpage truyện bé)."""
    own = session is None
    session = session or aiohttp.ClientSession()
    pid, tok = _page(page, token)
    t = aiohttp.ClientTimeout(total=30)
    try:
        async with session.get(f"{GRAPH}/{API_VER}/{pid}", params={"fields": "id,name", "access_token": tok},
                               timeout=t) as r:
            d = await _json(r)
        name = d.get("name") or d.get("id", "")
        async with session.get(f"{GRAPH}/{API_VER}/me", params={"fields": "id,name", "access_token": tok},
                               timeout=t) as r:
            me = await _json(r)
        if str(me.get("id") or "") != pid:
            raise FBError(f"Token đọc được Page «{name}» nhưng KHÔNG phải token của Page này: token đang là của "
                          f"«{me.get('name') or me.get('id')}» (token người dùng, hoặc token của Page khác). Trong Graph API "
                          f"Explorer chọn đúng Page «{name}» ở ô «User or Page» rồi chép token mới.", 200)
        missing = await _missing_scopes(session, tok, pid, t)
        if missing:
            raise FBError(f"Token của Page «{name}» thiếu quyền {', '.join(missing)}: tạo lại token, tick đủ "
                          f"{', '.join(POST_SCOPES)} và chọn Page này khi Facebook hỏi.", 200)
        return name
    finally:
        if own:
            await session.close()


async def _missing_scopes(session, tok: str, pid: str, timeout) -> list:
    """Quyền đăng bài còn thiếu theo debug_token. Facebook không cho tự kiểm (lỗi / không trả quyền) thì [] — không chặn."""
    try:
        async with session.get(f"{GRAPH}/{API_VER}/debug_token", params={"input_token": tok, "access_token": tok},
                               timeout=timeout) as r:
            data = (await _json(r)).get("data") or {}
    except Exception as e:
        logging.info("Facebook: không tự kiểm được quyền của token (%s)", str(e)[:120])
        return []
    scopes = set(data.get("scopes") or [])
    if not scopes:
        return []
    missing = [x for x in POST_SCOPES if x not in scopes]
    for g in data.get("granular_scopes") or []:
        ids = [str(i) for i in g.get("target_ids") or []]
        if g.get("scope") == "pages_manage_posts" and ids and pid not in ids and "pages_manage_posts" not in missing:
            missing.append("pages_manage_posts (cho Page này)")
    return missing


async def _upload_reel(session, path: str, description: str, when: float | None, page: str = "",
                       token: str = "") -> str:
    page, tok = _page(page, token)
    async with session.post(f"{GRAPH}/{API_VER}/{page}/video_reels",
                            json={"upload_phase": "start", "access_token": tok}) as r:
        d = await _json(r)
    vid = d["video_id"]
    size = os.path.getsize(path)
    with open(path, "rb") as f:
        async with session.post(d.get("upload_url") or f"{RUPLOAD}/video-upload/{API_VER}/{vid}", data=f,
                                headers={"Authorization": f"OAuth {tok}", "offset": "0", "file_size": str(size)},
                                timeout=aiohttp.ClientTimeout(total=1800)) as r:
            await _json(r)
    for _ in range(60):                                  # chờ Facebook nhận xong file (tối đa ~10 phút)
        async with session.get(f"{GRAPH}/{API_VER}/{vid}", params={"fields": "status", "access_token": tok}) as r:
            s = (await _json(r)).get("status") or {}
        if (s.get("uploading_phase") or {}).get("status") == "complete" or \
                s.get("video_status") in ("upload_complete", "processing", "ready"):
            break
        if s.get("video_status") in ("error", "upload_failed", "expired"):
            raise FBError(f"Facebook không nhận file: {s}")
        await asyncio.sleep(10)
    params = {"access_token": tok, "video_id": vid, "upload_phase": "finish", "description": description[:2200],
              "video_state": "SCHEDULED" if when else "PUBLISHED"}
    if when:
        params["scheduled_publish_time"] = str(int(when))
    async with session.post(f"{GRAPH}/{API_VER}/{page}/video_reels", params=params) as r:
        await _json(r)
    return vid


def _schedule_fields(when: float | None) -> dict:
    if not when:
        return {}
    return {"published": "false", "unpublished_content_type": "SCHEDULED", "scheduled_publish_time": str(int(when))}


async def _upload_video_chunked(session, path: str, title: str, description: str, when: float | None,
                                page: str = "", token: str = "") -> str:
    """Video thường, file lớn: giao thức gửi từng khúc của Graph API (upload_phase start -> transfer... -> finish).
    Facebook tự chọn cỡ khúc qua start_offset/end_offset; mỗi khúc gửi lỗi mạng thì gửi lại tối đa 3 lần."""
    page, tok = _page(page, token)
    url = f"{GRAPH_VIDEO}/{API_VER}/{page}/videos"
    size = os.path.getsize(path)
    async with session.post(url, data={"access_token": tok, "upload_phase": "start", "file_size": str(size)},
                            timeout=aiohttp.ClientTimeout(total=120)) as r:
        d = await _json(r)
    sid, vid = str(d["upload_session_id"]), str(d.get("video_id") or "")
    start, end = int(d["start_offset"]), int(d["end_offset"])
    with open(path, "rb") as f:
        while start < end:
            f.seek(start)
            chunk = f.read(end - start)
            for attempt in range(3):
                form = aiohttp.FormData()
                form.add_field("access_token", tok)
                form.add_field("upload_phase", "transfer")
                form.add_field("upload_session_id", sid)
                form.add_field("start_offset", str(start))
                form.add_field("video_file_chunk", chunk, filename="chunk.mp4", content_type="application/octet-stream")
                try:
                    async with session.post(url, data=form, timeout=aiohttp.ClientTimeout(total=900)) as r:
                        d = await _json(r)
                    break
                except FBError:
                    raise
                except Exception as e:                   # mạng chập chờn giữa chừng: gửi lại đúng khúc này
                    if attempt == 2:
                        raise
                    logging.info("Tự động đăng: gửi khúc %d lỗi (%s), gửi lại", start, str(e)[:80])
                    await asyncio.sleep(5)
            start, end = int(d["start_offset"]), int(d["end_offset"])
    fields = {"access_token": tok, "upload_phase": "finish", "upload_session_id": sid, "title": title[:250],
              "description": description[:5000], **_schedule_fields(when)}
    async with session.post(url, data=fields, timeout=aiohttp.ClientTimeout(total=300)) as r:
        d = await _json(r)
    return vid or str(d.get("video_id") or d.get("id") or "")


async def _upload_video(session, path: str, title: str, description: str, when: float | None,
                        thumb: str = "", page: str = "", token: str = "") -> str:
    page, tok = _page(page, token)
    if os.path.getsize(path) > RESUMABLE_MIN:
        vid = await _upload_video_chunked(session, path, title, description, when, page, tok)
        await _set_cover(session, vid, thumb, tok)       # giao thức từng khúc không có chỗ gửi ảnh bìa: gắn sau
        return vid
    form = aiohttp.FormData()
    form.add_field("access_token", tok)
    form.add_field("title", title[:250])
    form.add_field("description", description[:5000])
    for k, v in _schedule_fields(when).items():
        form.add_field(k, v)
    files = [open(path, "rb")]
    form.add_field("source", files[0], filename=os.path.basename(path), content_type="video/mp4")
    if thumb and os.path.exists(thumb):
        files.append(open(thumb, "rb"))
        form.add_field("thumb", files[1], filename="thumb.jpg", content_type="image/jpeg")
    try:
        async with session.post(f"{GRAPH_VIDEO}/{API_VER}/{page}/videos", data=form,
                                timeout=aiohttp.ClientTimeout(total=3600)) as r:
            d = await _json(r)
    finally:
        for f in files:
            f.close()
    return str(d.get("id") or d.get("video_id") or "")


async def _set_cover(session, vid: str, thumb: str, token: str = "") -> bool:
    """Gắn ảnh bìa AI chọn cho video/Reel vừa đăng (/{video-id}/thumbnails, is_preferred): API đăng Reels và giao thức
    gửi từng khúc không có chỗ gửi ảnh bìa. Facebook có cho đổi ảnh bìa theo đường này hay không còn tuỳ Page / phiên
    bản API, nên lỗi chỉ ghi log, bài vẫn giữ nguyên — video nấu ăn có đoạn mở đầu thì khung đầu đã là cảnh món đẹp nhất."""
    if not vid or not thumb or not os.path.exists(thumb):
        return False
    form = aiohttp.FormData()
    form.add_field("access_token", _page("", token)[1])
    form.add_field("is_preferred", "true")
    try:
        with open(thumb, "rb") as f:
            form.add_field("source", f, filename="cover.jpg", content_type="image/jpeg")
            async with session.post(f"{GRAPH}/{API_VER}/{vid}/thumbnails", data=form,
                                    timeout=aiohttp.ClientTimeout(total=120)) as r:
                await _json(r)
        logging.info("Tự động đăng: đã gắn ảnh bìa cho video %s", vid)
        return True
    except Exception as e:
        logging.info("Tự động đăng: Facebook không nhận ảnh bìa cho video %s (%s), dùng khung đầu video", vid,
                     str(e)[:150])
        return False


async def publish(path: str, title: str, description: str, duration: float, when: float | None,
                  thumb: str = "", session=None, page: str = "", token: str = "") -> tuple:
    """Đăng (hoặc hẹn giờ) lên Page. Trả (id video Facebook, "reel" | "video"). page/token: Fanpage khác Fanpage kênh
    bếp trong Cài đặt (truyện bé, 1.1.0)."""
    own = session is None
    session = session or aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=600))
    try:
        if duration <= REEL_MAX:
            vid = await _upload_reel(session, path, description, when, page, token)
            await _set_cover(session, vid, thumb, token)     # thử gắn ảnh bìa; lỗi cũng không làm hỏng bài đã đăng
            return vid, "reel"
        return await _upload_video(session, path, title, description, when, thumb, page, token), "video"
    finally:
        if own:
            await session.close()


async def views_of(video_id: str, session, token: str = "") -> int | None:
    async with session.get(f"{GRAPH}/{API_VER}/{video_id}/video_insights",
                           params={"access_token": _page("", token)[1]}) as r:
        d = await _json(r)
    vals = {x.get("name"): x for x in d.get("data", [])}
    for m in VIEW_METRICS:
        if m in vals:
            v = (vals[m].get("values") or [{}])[0].get("value")
            if isinstance(v, (int, float)):
                return int(v)
    return None


# ---------------- vòng chạy ----------------

def other_platforms(ch: str, job, video: str, title: str, desc: str, when: float | None) -> str:
    """Xếp video lên YouTube Shorts (kênh đã kết nối) và gói đăng TikTok cùng giờ hẹn `when` — sau khi Fanpage nhận bài,
    HOẶC khi Facebook dừng hẳn vì lỗi cấu hình (token / quyền / id Page): Facebook hỏng không kéo YouTube theo (26/11:
    token Fanpage truyện bé thiếu quyền, video 19:00 không lên YouTube dù vừa kết nối kênh). Mỗi job chỉ xếp một lần
    (Facebook sửa xong đăng lại thì không xếp trùng). Trả câu ghi thêm vào tin báo admin («» nếu không xếp gì mới)."""
    from rmvideo.app import tiktok_kit, youtube
    if ch == "kids":                              # 📼 giữ truyện cho video tổng hợp tuần (1.6.0); lỗi không ảnh hưởng bài đăng
        from rmvideo.app import kids_weekly
        kids_weekly.add(job, video, when)
    yt = youtube.after_facebook(ch, job, video, title, desc, when)
    tk = tiktok_kit.after_facebook(ch, job, video, desc, when)
    got = [x for x, ok in (("YouTube", yt), ("gói TikTok", tk)) if ok]
    if not got:
        return ""
    at = datetime.fromtimestamp(when, VN).strftime("%H:%M %d/%m") if when else "ngay"
    return f"\n▶️ {' và '.join(got)} vẫn theo lịch ({at})."


def _post_text(job) -> tuple:
    """(tiêu đề, mô tả) đăng Fanpage: chỉ phần «▶ Facebook» của gói nội dung (prompt_engine.platform_post). Trước đây
    gửi nguyên cả gói: mô tả bài có «📌», «▶ TikTok:», «▶ YouTube Shorts:», «#Shorts», caption lặp 3 lần."""
    post = (job.post or "").strip()
    title = post.split("\n", 1)[0].replace("📌", "").strip() if post else ""
    desc = post
    if "▶ Facebook:\n" in post:
        desc = post.split("▶ Facebook:\n", 1)[1].split("\n\n▶ ", 1)[0].strip()
    return title or "Video mới", desc or title


def _output_files(job) -> tuple:
    short = next((p["path"] for p in job.parts if p.get("label") == SHORT_LABEL and os.path.exists(p["path"])), "")
    if short and config.AUTO_POST_VERSION != "full":     # bản ngắn ≤ 90s: đăng Reels (lan toả tốt hơn video thường)
        thumb = next((p["path"] for p in job.parts if str(p.get("label", "")).startswith("Ảnh bìa")
                      and os.path.exists(p["path"])), "")
        return short, thumb
    video = next((p["path"] for p in job.parts if p.get("label") == "Video" and os.path.exists(p["path"])), "")
    video = video or (job.output if job.output and os.path.exists(job.output) else "")
    thumb = next((p["path"] for p in job.parts if str(p.get("label", "")).startswith("Ảnh bìa")
                  and os.path.exists(p["path"])), "")
    return video, thumb


RETRY_AFTER = 6 * 3600         # video / kênh / lượt xem đọc lỗi: thử lại sau 6 giờ, không gọi Facebook mỗi 2 phút
MAX_VIDEO_FAILS = 2            # một video nguồn lỗi (tải / làm / AI) chừng này lần thì bỏ hẳn
STREAK_PAUSE = 3               # chừng này video liên tiếp không đăng được thì dừng hẳn, báo admin
PAUSE_CODES = {190, 10, 200, 100, 368, 413}   # token hết hạn / thiếu quyền / sai id Page / bị chặn / file quá lớn: thử lại vô ích
_LOCK = asyncio.Lock()
_POSTED: dict = {}             # job id -> bài đã đăng (trong bộ nhớ): ghi file lỗi cũng không đăng lại


def _fail(st: dict, vid: str, src: str, now: float, why: str, hard: bool = False):
    """Ghi một lần lỗi của video nguồn. Lỗi cố định (khác kênh, quá dài...) hoặc lỗi lặp lại MAX_VIDEO_FAILS lần thì bỏ
    hẳn; lỗi tạm (mạng, hết hạn mức AI, đầy ổ...) thì cho video đó nghỉ RETRY_AFTER rồi thử lại."""
    f = st["fails"].setdefault(vid, {"n": 0})
    f["n"], f["next"], f["why"] = f["n"] + 1, now + RETRY_AFTER, why[:120]
    if hard or f["n"] >= MAX_VIDEO_FAILS:
        st["used"][vid] = {"at": now, "source": src, "skip": why[:120]}
    else:
        st["used"].pop(vid, None)


async def _listing(st: dict, plat: str, src: str, now: float) -> dict:
    """Danh sách video của một kênh (đọc lại sau LIST_TTL; lỗi thì nhớ, không đọc lại mỗi 2 phút).
    Facebook: ids là id video; TikTok: ids là "tt:<id>", kèm items {khoá: link, chú thích, độ dài}."""
    lst = st["listing"].get(src)
    if not lst or (now - lst.get("at", 0) > LIST_TTL and now - lst.get("fail_at", 0) > RETRY_AFTER / 6):
        try:
            if plat == "tiktok":
                items, owner = await asyncio.to_thread(list_tiktok_sync, src)
                lst = st["listing"][src] = {"at": now, "ids": [f"tt:{x['id']}" for x in items], "owner": owner,
                                            "items": {f"tt:{x['id']}": x for x in items}}
            else:
                ids, owner = await asyncio.to_thread(list_channel_sync, src)
                lst = st["listing"][src] = {"at": now, "ids": ids, "owner": owner}
        except Exception as e:
            logging.warning("Tự động đăng: không đọc được kênh %s (%s)", src, str(e)[:120])
            lst = st["listing"][src] = {**(lst or {"ids": [], "owner": ""}), "fail_at": now, "err": str(e)[:120]}
    return lst


def _video_url(plat: str, key: str, lst: dict) -> str:
    if plat == "tiktok":
        return (lst.get("items") or {}).get(key, {}).get("url") or ""
    return f"https://www.facebook.com/reel/{key}/"


def _owner_mismatch(plat: str, lst: dict, info: dict) -> bool:
    if plat == "tiktok":                          # yt-dlp TikTok: uploader = tên kênh (@...)
        up = str(info.get("uploader") or "").lower().lstrip("@")
        return bool(lst.get("owner") and up and up != lst["owner"])
    up = str(info.get("uploader_id") or "")
    return bool(lst.get("owner") and up and up != lst["owner"])


def _manual_key(url: str) -> str:
    return "m:" + hashlib.sha1(url.encode()).hexdigest()[:12]


async def queue_link(url: str) -> dict:
    """Người dùng dán link MỘT video: kiểm link (nền tảng được phép), xem thử (tiêu đề, độ dài), xếp vào hàng chờ riêng.
    Lượt lấy video kế tiếp của bot làm video này trước, rồi mới chọn ngẫu nhiên từ kênh nguồn. Ném ValueError."""
    import core_video
    url = await url_guard.check_url_async((url or "").strip())
    with tempfile.TemporaryDirectory() as td:            # xem thử NGOÀI khoá: yt-dlp mất vài giây
        info = await core_video.probe_formats(url, td)
    dur = int(info.get("duration") or 0)
    if dur > config.LONG_MAX:
        raise ValueError(f"Video dài {dur}s, quá {config.LONG_MAX}s")
    if 0 < dur < 5:
        raise ValueError("Video quá ngắn (dưới 5 giây)")
    key = _manual_key(url)
    async with _LOCK:
        st = load_state()
        if any(m.get("url") == url for m in st["manual"]):
            raise ValueError("Link này đã có trong hàng chờ")
        used = st["used"].get(key)
        dup = duplicate_of(st, key, info)
        if (used and not used.get("skip")) or dup:
            raise ValueError(f"Video này đã làm trước đó (job #{(used or st['used'].get(dup, {})).get('job', '?')})")
        entry = {"url": url, "title": (info.get("title") or "")[:200], "dur": dur, "at": time.time(), "key": key}
        st["manual"].append(entry)
        save_state(st)
    return entry


async def remove_link(url: str) -> bool:
    async with _LOCK:
        st = load_state()
        rest = [m for m in st["manual"] if m.get("url") != (url or "").strip()]
        if len(rest) == len(st["manual"]):
            return False
        st["manual"] = rest
        save_state(st)
    return True


def _enqueue(st, plat, vid, src, url, info, slot, now, queue, Job, QueueFull) -> str:
    """Tạo job làm lại (source="auto") và ghi pending. Trả "job #id"; hàng đợi đầy thì ném QueueFull."""
    dur = info.get("duration") or 0
    voice = config.default_voice()
    mode = config.AUTO_MODE if config.AUTO_MODE in ("cook", "review") else "cook"
    from rmvideo.app import job_factory
    job = job_factory.auto(url=url, title=info.get("title", ""), duration=dur, mode=mode, voice=voice,
                           chat_id=config.admin_chat_id() or 0)
    queue.put(job)
    st["used"][vid] = {"at": now, "source": src, "job": job.id, "plat": plat, "dur": dur,
                       "title": _norm_title(info.get("title") or "")}
    st["pending"] = {"job": job.id, "vid": vid, "source": src, "slot_ts": slot[0], "slot": slot[1],
                     "dur": dur, "plat": plat}
    logging.info("Tự động đăng: job #%s lấy video %s của %s (%ds) cho khung %s %s", job.id, vid, src, dur,
                 slot[1], datetime.fromtimestamp(slot[0], VN).strftime("%d/%m"))
    return f"job #{job.id}"


async def _pick_manual(st, slot, now, core_video, Job, QueueFull, queue) -> str:
    """Link người dùng dán (theo thứ tự dán) đi trước video chọn ngẫu nhiên. Link hỏng thì báo admin và bỏ qua."""
    from state import notify_admin
    while st["manual"]:
        m = st["manual"][0]
        try:
            with tempfile.TemporaryDirectory() as td:
                info = await core_video.probe_formats(m["url"], td)
        except Exception as e:
            st["manual"].pop(0)
            logging.warning("Tự động đăng: link dán %s không xem được (%s), bỏ qua", m["url"], str(e)[:100])
            await notify_admin(f"⚠️ Link bạn dán không xem được, đã bỏ: {m['url']} ({str(e)[:100]})")
            continue
        try:
            msg = _enqueue(st, detect_platform(m["url"]) or "link", m.get("key") or _manual_key(m["url"]), "link dán tay",
                           m["url"], info, slot, now, queue, Job, QueueFull)
        except QueueFull:
            return "hàng đợi đầy, thử lại sau"
        st["manual"].pop(0)
        return msg
    return ""


async def _pick_and_queue(st: dict, slot: tuple, now: float, rnd: random.Random) -> str:
    import core_video
    from queue_manager import Job, QueueFull
    from state import queue
    msg = await _pick_manual(st, slot, now, core_video, Job, QueueFull, queue)
    if msg:
        return msg
    if not all_sources():
        return "chưa có kênh nguồn: thêm kênh hoặc dán link video ở mục Tự động đăng"
    for plat in _platform_order(st, rnd):
        srcs = [s for p, s in all_sources() if p == plat]
        rnd.shuffle(srcs)
        msg = await _pick_from(st, plat, srcs, slot, now, rnd, core_video, Job, QueueFull, queue)
        if msg:
            return msg
    return "hết video mới ở các kênh nguồn (chờ kênh đăng thêm)"


async def _pick_from(st, plat, srcs, slot, now, rnd, core_video, Job, QueueFull, queue) -> str:
    for src in srcs:
        lst = await _listing(st, plat, src, now)
        cands = [v for v in lst.get("ids", []) if v not in st["used"]
                 and st["fails"].get(v, {}).get("next", 0) <= now]
        rnd.shuffle(cands)
        for vid in cands[:3]:
            url = _video_url(plat, vid, lst)
            if not url:
                continue
            try:
                with tempfile.TemporaryDirectory() as td:
                    info = await core_video.probe_formats(url, td)
            except Exception as e:
                _fail(st, vid, src, now, f"không xem được: {str(e)[:80]}")
                continue
            dur = info.get("duration") or 0
            dup = duplicate_of(st, vid, info)
            ad = recipe.looks_like_ad(info.get("title") or "", dur) if config.AUTO_SKIP_ADS == "1" else ""
            min_h = int(config.AUTO_MIN_HEIGHT or 0)
            short = int(info.get("max_short") or 0)
            why = ("khác kênh" if _owner_mismatch(plat, lst, info) else
                   ad if ad else
                   f"nguồn chỉ {short}p < {min_h}p" if min_h and 0 < short < min_h else
                   f"dài {dur}s > {config.LONG_MAX}s" if dur > config.LONG_MAX else
                   "quá ngắn" if 0 < dur < 5 else
                   f"trùng video đã làm ({dup})" if dup else "")
            if why:
                _fail(st, vid, src, now, why, hard=True)
                continue
            try:
                return _enqueue(st, plat, vid, src, url, info, slot, now, queue, Job, QueueFull)
            except QueueFull:
                return "hàng đợi đầy, thử lại sau"
    return ""


async def _job_failed(st: dict, p: dict, now: float, why: str) -> str:
    from state import notify_admin
    logging.warning("Tự động đăng: video %s không đăng được (%s), chọn video khác", p["vid"], why)
    _fail(st, p["vid"], p["source"], now, why)
    st["pending"] = None
    st["streak"] = st.get("streak", 0) + 1
    if st["streak"] >= STREAK_PAUSE:
        st["paused"] = f"{st['streak']} video liên tiếp không đăng được, lần cuối: {why[:150]}"
        await notify_admin(f"⛔ Tự động đăng đã dừng: {st['paused']}. Sửa xong gõ  auto_resume  (hoặc bấm nút trên web).")
    return why


async def _finish_pending(st: dict, now: float, rnd: random.Random) -> str:
    from state import notify_admin, queue
    p = st["pending"]
    if p["job"] in _POSTED:                     # đã đăng ở lượt trước nhưng ghi file lỗi: chỉ ghi lại, KHÔNG đăng lại
        if not any(x.get("job") == p["job"] for x in st["posts"]):
            st["posts"].append(_POSTED[p["job"]])
        st["pending"] = None
        return f"job #{p['job']} đã đăng trước đó"
    if p.get("publishing"):                     # bot dừng / ghi file lỗi đúng lúc đang tải lên: không biết đã lên chưa
        st["pending"] = None
        st["used"][p["vid"]] = {"at": now, "source": p["source"], "skip": "dừng giữa lúc đăng"}
        await notify_admin(f"⚠️ Bot dừng đúng lúc đang đăng video #{p['job']} lên Fanpage. Mở Fanpage kiểm tra (kể cả "
                           "mục bài đã lên lịch); bot KHÔNG tự đăng lại video này để tránh trùng.")
        return f"job #{p['job']} dừng giữa lúc đăng, không đăng lại"
    if p.get("next_try", 0) > now:
        return "chờ thử đăng lại lúc " + datetime.fromtimestamp(p["next_try"], VN).strftime("%H:%M")
    job = queue.jobs.get(p["job"])
    if job is None:
        return await _job_failed(st, p, now, "job tự động không còn trong danh sách")
    if job.status in ("queued", "processing", "approved"):
        return f"đang làm job #{job.id}"
    why_skip = next((m for m in SKIP_MARKS if m in (job.error or "") + str(getattr(job, "no_autopost", ""))), "")
    if why_skip and job.status in ("done", "error"):
        # video quảng cáo / không phải công thức / trùng video đã làm (job dừng sớm): bỏ hẳn video nguồn, KHÔNG tính
        # là lỗi liên tiếp (3 video quảng cáo liền nhau không được làm dừng tự đăng)
        _fail(st, p["vid"], p["source"], now, why_skip, hard=True)
        st["pending"] = None
        return f"job #{job.id}: {why_skip}, chọn video khác"
    fp = (getattr(job, "source_meta", None) or {}).get("fp")
    if fp and job.status == "done":                 # dấu vân hình của video đã làm (chống trùng lần sau)
        fps = st.setdefault("fps", {})
        fps[p["vid"]] = fp
        for k in list(fps)[:-dedupe.KEEP]:
            del fps[k]
    if job.status != "done":
        return await _job_failed(st, p, now, f"job #{job.id} {job.status}: {(job.error or '')[:100]}")
    if str(getattr(job, "no_autopost", "")).startswith(recipe.NOT_RECIPE):
        # video quảng cáo / không phải công thức (AI đọc lời gốc): bỏ hẳn video nguồn, KHÔNG tính là lỗi liên tiếp
        _fail(st, p["vid"], p["source"], now, job.no_autopost, hard=True)
        st["pending"] = None
        return f"job #{job.id}: {job.no_autopost}, chọn video khác"
    if getattr(job, "no_autopost", ""):         # AI lỗi / lời mới gần như chép lời gốc: không đăng công khai
        return await _job_failed(st, p, now, f"job #{job.id}: {job.no_autopost}")
    video, thumb = _output_files(job)
    if not video:
        return await _job_failed(st, p, now, f"job #{job.id} không còn file video")
    when = p["slot_ts"]
    if when < now + LEAD:                       # trễ khung giờ (máy chậm/bot tắt): sang khung trống kế tiếp
        nxt = free_slots(st, now, rnd)
        when = nxt[0][0] if nxt else None       # không còn khung nào trong 36 giờ: đăng ngay
        p["slot"] = nxt[0][1] if nxt else datetime.fromtimestamp(now, VN).strftime("%H:%M")
    title, desc = _post_text(job)
    dur = job.out_dur or p.get("dur") or 0
    if any(x.get("path") == video and x.get("label") == SHORT_LABEL for x in job.parts):
        import core_video
        dur = await core_video.probe_duration(video)          # bản ngắn: độ dài thật (≤ 90s -> Reels API)
    p["publishing"] = now
    save_state(st)                              # ghi dấu TRƯỚC khi tải lên; ghi lỗi thì dừng, chưa đăng gì
    try:
        fb_id, kind = await publish(video, title, desc, dur, when, thumb)
    except Exception as e:
        p.pop("publishing", None)
        p["tries"] = p.get("tries", 0) + 1
        p["next_try"] = now + min(3600, 300 * 2 ** (p["tries"] - 1))     # 5, 10, 20, 40, 60 phút
        code = e.code if isinstance(e, FBError) else 0
        if code in PAUSE_CODES or p["tries"] >= 5:
            st["paused"] = str(e)[:200]
            others = other_platforms("cook", job, video, title, desc, when)
            await notify_admin(f"⛔ Tự động đăng Facebook đã dừng: {str(e)[:200]}. Kiểm tra FB_PAGE_ID / FB_PAGE_TOKEN "
                               f"trong Cài đặt rồi gõ  auto_resume  (video #{job.id} vẫn giữ để đăng lại)." + others)
        raise
    rec = {"fb_id": fb_id, "kind": kind, "job": job.id, "vid": p["vid"], "source": p["source"],
           "slot": p["slot"], "time": when or now, "views": None}
    _POSTED[job.id] = rec
    st["posts"].append(rec)
    st["pending"] = None
    st["streak"] = 0
    st["fails"].pop(p["vid"], None)
    try:
        save_state(st)                          # ghi ngay, không đợi cuối lượt
    except OSError as e:
        logging.error("Tự động đăng: đã đăng %s nhưng không ghi được autopost.json (%s)", fb_id, e)
    other_platforms("cook", job, video, title, desc, when)            # ▶️ YouTube Shorts + 🎵 gói TikTok cùng giờ
    at = datetime.fromtimestamp(when or now, VN).strftime("%H:%M %d/%m")
    logging.info("Tự động đăng: %s %s lên Page, %s %s", kind, fb_id, "hẹn" if when else "đăng ngay", at)
    await notify_admin(f"📅 Đã {'hẹn đăng' if when else 'đăng'} video #{job.id} lên Fanpage lúc {at}: {title[:80]}")
    return f"đã {'hẹn' if when else 'đăng'} {kind} {fb_id} lúc {at}"


async def _update_views(st: dict, now: float):
    """Lượt xem sau 24 giờ cho việc chọn giờ vàng. Đọc lỗi thì 6 giờ sau mới thử lại; quá 7 ngày thì thôi (không ghi
    0: số 0 giả làm lệch việc chọn giờ)."""
    todo = [p for p in st["posts"] if p.get("views") is None and p.get("fb_id") and not p.get("views_done")
            and now - p.get("time", now) >= 24 * 3600 and now - p.get("views_try", 0) >= RETRY_AFTER]
    if not todo:
        return
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30)) as s:
        for p in todo[:3]:
            p["views_try"] = now
            try:
                v = await views_of(p["fb_id"], s)
            except Exception as e:
                logging.info("Tự động đăng: chưa đọc được lượt xem %s (%s)", p["fb_id"], str(e)[:100])
                v = None
            if v is not None:
                p["views"] = v
                logging.info("Tự động đăng: bài %s khung %s được %s lượt xem sau 24 giờ", p["fb_id"], p["slot"], v)
            elif now - p["time"] > 7 * 86400:
                p["views_done"] = True


async def tick(now: float | None = None, rnd: random.Random | None = None, force: bool = False) -> str:
    """Một vòng: xong job thì đăng; còn khung giờ trống trong 36 giờ tới mà hàng đợi rảnh thì lấy video mới.
    force=True: không chờ hàng đợi trống. Chỉ MỘT lượt chạy tại một thời điểm (vòng nền, nút web, lệnh console):
    hai lượt cùng lúc từng có thể đăng trùng một video."""
    if _LOCK.locked():
        return "một lượt khác đang chạy, thử lại sau ít phút"
    async with _LOCK:
        return await _tick(now, rnd, force)


async def _tick(now, rnd, force) -> str:
    from state import queue
    now = now or time.time()
    rnd = rnd or random.Random()
    st = load_state()
    why = enabled(st)
    if why:
        return why
    if st["paused"]:
        return "đang dừng vì lỗi: " + st["paused"]
    try:
        if st["pending"]:
            msg = await _finish_pending(st, now, rnd)
            if st["pending"] or st["paused"]:
                return msg
        try:
            await _update_views(st, now)
        except Exception as e:
            logging.info("Tự động đăng: lỗi đọc lượt xem (%s)", str(e)[:100])
        slots = free_slots(st, now, rnd)
        if not slots and not st["manual"]:
            return "đã đủ video cho các khung giờ trong 36 giờ tới"
        if queue.pending and not force:
            return "chờ hàng đợi trống (video bạn gửi được làm trước)"
        # link dán tay mà hết khung trống: vẫn làm ngay, xong sẽ hẹn vào khung trống kế tiếp (hoặc đăng ngay nếu hết khung)
        slot = slots[0] if slots else (now, datetime.fromtimestamp(now, VN).strftime("%H:%M"))
        return await _pick_and_queue(st, slot, now, rnd)
    finally:
        save_state(st)


async def resume() -> str:
    async with _LOCK:
        st = load_state()
        st["paused"] = ""
        st["streak"] = 0
        save_state(st)
    return "Đã chạy lại. " + await tick()


def status_text() -> str:
    st = load_state()
    now = time.time()
    why = enabled(st)
    lines = [f"🤖 Tự động đăng: {'BẬT' if not why else 'tắt — ' + why}" + (f" | DỪNG: {st['paused']}" if st["paused"] else "")]
    on = platforms()
    lines.append(f"Nguồn đang tick: {' + '.join(p.capitalize() for p in on)}"
                 + (" (xen kẽ hai nền tảng)" if len(on) == 2 else "") + f" | {per_day()} video/ngày | giờ: "
                 + (", ".join(fixed_times()) or "tự chọn giờ vàng"))
    lines.append(f"Kênh Facebook: {', '.join(sources()) or '(chưa có)'}")
    lines.append(f"Kênh TikTok: {', '.join(tiktok_sources()) or '(chưa có)'}")
    if st["manual"]:
        lines.append(f"Link bạn dán đang chờ ({len(st['manual'])}, làm trước video ngẫu nhiên): "
                     + "; ".join((m.get("title") or m.get("url", ""))[:50] for m in st["manual"][:3])
                     + (" …" if len(st["manual"]) > 3 else ""))
    rnd = random.Random(0)
    today = datetime.fromtimestamp(now, VN).date().isoformat()
    if not why:
        lines.append(f"Khung giờ hôm nay: {', '.join(day_slots(st, today, rnd))}")
    if st["pending"]:
        p = st["pending"]
        lines.append(f"Đang làm: job #{p['job']} cho khung {p['slot']} "
                     f"{datetime.fromtimestamp(p['slot_ts'], VN).strftime('%d/%m')}")
    fut = [p for p in st["posts"] if p.get("time", 0) > now]
    if fut:
        lines.append("Đã hẹn: " + ", ".join(datetime.fromtimestamp(p["time"], VN).strftime("%H:%M %d/%m") for p in fut))
    stats = slot_stats(st)
    if stats:
        lines.append("Lượt xem TB sau 24h theo khung: " + ", ".join(
            f"{k} {sum(v) / len(v):.0f} ({len(v)} bài)" for k, v in sorted(stats.items())))
    tt = sum(1 for k in st["used"] if k.startswith("tt:"))
    lines.append(f"Đã dùng {len(st['used'])} video nguồn (Facebook {len(st['used']) - tt}, TikTok {tt}), "
                 f"đã đăng {len(st['posts'])} bài.")
    from rmvideo.app import youtube
    lines += youtube.status_lines("cook", now)
    from rmvideo.app.flow import hooks
    lines += hooks.status_lines("cook")
    from rmvideo.app import tiktok_kit
    lines += tiktok_kit.status_lines("cook", now)
    if not why:
        save_state(st)                       # khung giờ hôm nay vừa chọn (nếu chưa có) phải giữ nguyên cho vòng chạy
    return "\n".join(lines)


async def run_forever(every: float = 120):
    await asyncio.sleep(60)                    # để bot khởi động xong, tự kiểm tra ffmpeg trước
    while True:
        try:
            msg = await tick()
            if msg and not msg.startswith(("AUTO_POST đang tắt", "đang làm", "đã đủ", "chờ hàng đợi", "một lượt",
                                           "chờ thử đăng lại", "đang dừng", "thiếu FB", "chưa có kênh")):
                logging.info("Tự động đăng: %s", msg)
        except Exception as e:
            logging.warning("Tự động đăng lỗi: %s", str(e)[:200])
        await asyncio.sleep(every)

